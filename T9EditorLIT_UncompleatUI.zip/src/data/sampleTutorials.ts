import { TranscriptLine } from '../utils/editor';

export interface TutorialProject {
  id: string;
  title: string;
  fileName: string;
  duration: number; // seconds
  resolution: string;
  fps: number;
  lines: TranscriptLine[];
  codeSnippets: {
    [key: string]: {
      file: string;
      code: string;
      terminal?: string;
      activeLine?: number;
    };
  };
}

export const SAMPLE_TUTORIALS: TutorialProject[] = [
  {
    id: 'ts-generics',
    title: 'Building a Strict Type-Safe Event Bus in TypeScript 5.6',
    fileName: 'tut_ts56_event_bus_raw_take01.mp4',
    duration: 520, // 8m 40s
    resolution: '1920x1080',
    fps: 60,
    codeSnippets: {
      intro: {
        file: 'src/eventBus.ts',
        activeLine: 1,
        code: `// RatioCut Tutorial Demo: Type-Safe Event Bus
export type EventKey = string | symbol;
export type EventReceiver<T = any> = (payload: T) => void;

export class TypedEventBus<Events extends Record<EventKey, any>> {
  private listeners = new Map<keyof Events, Set<Function>>();
}`,
        terminal: '$ npm run typecheck\nChecking syntax and generic bounds...',
      },
      genericConstraint: {
        file: 'src/types.ts',
        activeLine: 7,
        code: `export type EventMap = {
  'user:login': { userId: string; timestamp: number };
  'user:logout': { userId: string; reason?: string };
  'cart:checkout': { cartId: string; totalCents: number };
};

export type Listener<T> = (data: T) => void | Promise<void>;`,
        terminal: '$ tsc --noEmit\nFound 0 errors. Watching for changes...',
      },
      flubArea: {
        file: 'src/types.ts',
        activeLine: 12,
        code: `// [TEMP COMPILER ERROR TESTING]
type BrokenConstraint = keyof any;
// Err: Type 'any' does not satisfy constraint 'Record<string, unknown>'`,
        terminal: 'Error: Cannot find module @types/events\n(Speaker stumbled on import)',
      },
      implementation: {
        file: 'src/eventBus.ts',
        activeLine: 14,
        code: `export class TypedEventBus<Events extends Record<string, any>> {
  private bus = new Map<keyof Events, Set<Listener<any>>>();

  on<E extends keyof Events>(event: E, handler: Listener<Events[E]>): () => void {
    if (!this.bus.has(event)) {
      this.bus.set(event, new Set());
    }
    this.bus.get(event)!.add(handler);
    return () => this.off(event, handler);
  }
}`,
        terminal: '$ vitest run\nPASS src/eventBus.test.ts (4 tests passed)',
      },
      testing: {
        file: 'src/eventBus.test.ts',
        activeLine: 8,
        code: `test('dispatches strictly typed payload', () => {
  const bus = new TypedEventBus<EventMap>();
  bus.on('user:login', (data) => {
    // data.userId is string, data.timestamp is number
    expect(data.userId).toBe('usr_73');
  });
  bus.emit('user:login', { userId: 'usr_73', timestamp: Date.now() });
});`,
        terminal: 'PASS  src/eventBus.test.ts\nTest Suites: 1 passed, 1 total\nTime: 1.28s',
      },
    },
    lines: [
      {
        id: 't1',
        startTime: 0,
        endTime: 14,
        text: 'Welcome back to the channel. Today we are designing a production-grade, zero-overhead type-safe event bus in TypeScript.',
        status: 'kept',
        category: 'explanation',
      },
      {
        id: 't2',
        startTime: 14,
        endTime: 28,
        text: 'Standard Node EventEmitter loses payload types easily, creating nasty runtime crashes in microservices.',
        status: 'kept',
        category: 'explanation',
      },
      {
        id: 't3',
        startTime: 28,
        endTime: 42,
        text: 'Uh, wait... let me just kill my music player in the background. Sorry about that mic bleed.',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'flub',
      },
      {
        id: 't4',
        startTime: 42,
        endTime: 49,
        text: '[Awkward 7-second silence while adjusting microphone stand]',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'pause',
      },
      {
        id: 't5',
        startTime: 49,
        endTime: 75,
        text: 'Alright, starting in `src/types.ts`. Let us declare an `EventMap` record where each event name maps to its payload schema.',
        status: 'kept',
        category: 'coding',
      },
      {
        id: 't6',
        startTime: 75,
        endTime: 98,
        text: 'Notice here: by indexing `Events[E]`, the handler function parameter is automatically deduced with zero type casting.',
        status: 'kept',
        category: 'coding',
      },
      {
        id: 't7',
        startTime: 98,
        endTime: 122,
        text: 'Now let us write the `TypedEventBus` class. We store listeners inside a native `Map` keyed by event name.',
        status: 'unreviewed',
        category: 'coding',
      },
      {
        id: 't8',
        startTime: 122,
        endTime: 139,
        text: 'Wait, why is ESLint yelling here? Oh, I imported the wrong type definition. Let me re-type that line.',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'flub',
      },
      {
        id: 't9',
        startTime: 139,
        endTime: 146,
        text: '[Dead silence typing and deleting the bad import]',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'pause',
      },
      {
        id: 't10',
        startTime: 146,
        endTime: 175,
        text: 'Right, we use `Set<Listener<Events[E]>>` to ensure we can unsubscribe in O(1) time without memory leaks.',
        status: 'kept',
        category: 'coding',
      },
      {
        id: 't11',
        startTime: 175,
        endTime: 210,
        text: 'The `on` method returns an unbind teardown function directly, making it extremely ergonomic for React `useEffect` cleanups.',
        status: 'unreviewed',
        category: 'coding',
      },
      {
        id: 't12',
        startTime: 210,
        endTime: 232,
        text: 'Let us also implement the `emit` method. If no listeners exist for the key, we bail early to save execution cycles.',
        status: 'unreviewed',
        category: 'coding',
      },
      {
        id: 't13',
        startTime: 232,
        endTime: 248,
        text: 'Umm... cough... excuse me, let me take a quick sip of water.',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'flub',
      },
      {
        id: 't14',
        startTime: 248,
        endTime: 285,
        text: 'Next, let us write an automated test in Vitest to verify that invalid payload keys trigger strict TypeScript compile errors.',
        status: 'unreviewed',
        category: 'coding',
      },
      {
        id: 't15',
        startTime: 285,
        endTime: 320,
        text: 'As you can see, passing a string to `totalCents` immediately lights up red in VS Code with a clear error diagnostic.',
        status: 'unreviewed',
        category: 'explanation',
      },
      {
        id: 't16',
        startTime: 320,
        endTime: 350,
        text: 'Let us run `npm test` in the terminal to verify runtime dispatch works as expected across all subscriber instances.',
        status: 'unreviewed',
        category: 'terminal',
      },
      {
        id: 't17',
        startTime: 350,
        endTime: 365,
        text: 'Hang on, why did the test runner fail? Ah, Vitest cache was stale. Re-running with `--no-cache`.',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'flub',
      },
      {
        id: 't18',
        startTime: 365,
        endTime: 395,
        text: 'All 4 test suites pass in 1.28 seconds with 100% code coverage. Clean, decoupled, and strictly typed.',
        status: 'unreviewed',
        category: 'terminal',
      },
      {
        id: 't19',
        startTime: 395,
        endTime: 440,
        text: 'In summary: use generic key constraints, return teardown callbacks, and let TypeScript infer event payloads automatically.',
        status: 'unreviewed',
        category: 'explanation',
      },
      {
        id: 't20',
        startTime: 440,
        endTime: 470,
        text: 'If you found this tutorial helpful, hit the like button and grab the GitHub repository link pinned in the description below.',
        status: 'unreviewed',
        category: 'explanation',
      },
      {
        id: 't21',
        startTime: 470,
        endTime: 520,
        text: '[Outro music playing with end-screen cards]',
        status: 'unreviewed',
        category: 'pause',
      },
    ],
  },
  {
    id: 'react-server-actions',
    title: 'React 19 Server Actions & Optimistic UI Updates',
    fileName: 'tut_react19_server_actions_uncut.mp4',
    duration: 420,
    resolution: '1920x1080',
    fps: 60,
    codeSnippets: {
      intro: {
        file: 'app/actions.ts',
        activeLine: 1,
        code: `'use server';
import { db } from '@/lib/db';

export async function updateLikeCount(postId: string, current: number) {
  // Database mutation executed directly on server
  await db.posts.update(postId, { likes: current + 1 });
  return { success: true };
}`,
        terminal: '$ next dev\nReady in 1400ms on http://localhost:3000',
      },
    },
    lines: [
      {
        id: 'r1',
        startTime: 0,
        endTime: 16,
        text: 'Today we are exploring the brand new `useOptimistic` hook and Server Actions in React 19.',
        status: 'kept',
        category: 'explanation',
      },
      {
        id: 'r2',
        startTime: 16,
        endTime: 29,
        text: 'Uhh, let me zoom in on my VS Code so you guys can see the font properly.',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'flub',
      },
      {
        id: 'r3',
        startTime: 29,
        endTime: 65,
        text: 'Notice that with Server Actions, you do not need to create manual `/api` route handlers or manage fetch state boilerplate.',
        status: 'kept',
        category: 'explanation',
      },
      {
        id: 'r4',
        startTime: 65,
        endTime: 110,
        text: 'When the button is clicked, `useOptimistic` immediately increments the counter before the server mutation finishes.',
        status: 'unreviewed',
        category: 'coding',
      },
      {
        id: 'r5',
        startTime: 110,
        endTime: 125,
        text: 'Wait, my dev server crashed because port 3000 was busy. Let me kill node process.',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'flub',
      },
      {
        id: 'r6',
        startTime: 125,
        endTime: 170,
        text: 'If the server throws a network error, React automatically rolls back the optimistic value to the previous state.',
        status: 'unreviewed',
        category: 'explanation',
      },
      {
        id: 'r7',
        startTime: 170,
        endTime: 220,
        text: 'This gives you instant 60fps UI feedback on high-latency mobile networks without writing manual cache rollbacks.',
        status: 'unreviewed',
        category: 'explanation',
      },
      {
        id: 'r8',
        startTime: 220,
        endTime: 240,
        text: '[Long 20s pause while searching for documentation]',
        status: 'cut',
        isFlubOrSilence: true,
        category: 'pause',
      },
      {
        id: 'r9',
        startTime: 240,
        endTime: 310,
        text: 'Let us inspect the Network tab: notice only a tiny 42-byte payload is transmitted over the wire.',
        status: 'unreviewed',
        category: 'terminal',
      },
      {
        id: 'r10',
        startTime: 310,
        endTime: 420,
        text: 'That is how you build zero-latency forms in React 19. Check the code in the GitHub link below.',
        status: 'unreviewed',
        category: 'explanation',
      },
    ],
  },
];
